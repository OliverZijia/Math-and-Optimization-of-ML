import numpy as np
import matplotlib.pyplot as plt

l1 = np.zeros(2)
l1[0] = 1
l1[1] = 2
print(l1)